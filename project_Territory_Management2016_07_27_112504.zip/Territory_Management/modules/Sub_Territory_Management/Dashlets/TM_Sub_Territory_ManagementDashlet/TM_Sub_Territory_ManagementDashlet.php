<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
/*********************************************************************************
 * $Id$
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

require_once('include/Dashlets/DashletGeneric.php');
require_once('modules/TM_Sub_Territory_Management/TM_Sub_Territory_Management.php');

class TM_Sub_Territory_ManagementDashlet extends DashletGeneric { 
    function TM_Sub_Territory_ManagementDashlet($id, $def = null) {
		global $current_user, $app_strings;
		require('modules/TM_Sub_Territory_Management/metadata/dashletviewdefs.php');

        parent::DashletGeneric($id, $def);

        if(empty($def['title'])) $this->title = translate('LBL_HOMEPAGE_TITLE', 'TM_Sub_Territory_Management');

        $this->searchFields = $dashletData['TM_Sub_Territory_ManagementDashlet']['searchFields'];
        $this->columns = $dashletData['TM_Sub_Territory_ManagementDashlet']['columns'];

        $this->seedBean = new TM_Sub_Territory_Management();        
    }
}