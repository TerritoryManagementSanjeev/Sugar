<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$relationships = array (
  'tm_sub_territory_management_accounts' => 
  array (
    'rhs_label' => 'Accounts',
    'lhs_label' => 'Sub Territories',
    'rhs_subpanel' => 'default',
    'lhs_module' => 'TM_Sub_Territory_Management',
    'rhs_module' => 'Accounts',
    'relationship_type' => 'one-to-many',
    'readonly' => false,
    'deleted' => false,
    'relationship_only' => false,
    'for_activities' => false,
    'is_custom' => false,
    'from_studio' => false,
    'relationship_name' => 'tm_sub_territory_management_accounts',
  ),
  'tm_sub_territory_management_opportunities' => 
  array (
    'rhs_label' => 'Opportunities',
    'lhs_label' => 'Sub Territories',
    'rhs_subpanel' => 'default',
    'lhs_module' => 'TM_Sub_Territory_Management',
    'rhs_module' => 'Opportunities',
    'relationship_type' => 'one-to-many',
    'readonly' => false,
    'deleted' => false,
    'relationship_only' => false,
    'for_activities' => false,
    'is_custom' => false,
    'from_studio' => false,
    'relationship_name' => 'tm_sub_territory_management_opportunities',
  ),
  'tm_sub_territory_management_contacts' => 
  array (
    'rhs_label' => 'Contacts',
    'lhs_label' => 'Sub Territories',
    'rhs_subpanel' => 'default',
    'lhs_module' => 'TM_Sub_Territory_Management',
    'rhs_module' => 'Contacts',
    'relationship_type' => 'one-to-many',
    'readonly' => false,
    'deleted' => false,
    'relationship_only' => false,
    'for_activities' => false,
    'is_custom' => false,
    'from_studio' => false,
    'relationship_name' => 'tm_sub_territory_management_contacts',
  ),
  'tm_sub_territory_management_users' => 
  array (
    'rhs_label' => 'Users',
    'lhs_label' => 'Sub Territories',
    'rhs_subpanel' => 'default',
    'lhs_module' => 'TM_Sub_Territory_Management',
    'rhs_module' => 'Users',
    'relationship_type' => 'one-to-many',
    'readonly' => false,
    'deleted' => false,
    'relationship_only' => false,
    'for_activities' => false,
    'is_custom' => false,
    'from_studio' => false,
    'relationship_name' => 'tm_sub_territory_management_users',
  ),
);